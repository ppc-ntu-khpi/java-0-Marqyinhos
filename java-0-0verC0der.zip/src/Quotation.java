public class Quotation {
  String quote = "“That which does not kill us makes us stronger.”";
  String name = "– Friedrich Nietzsche";
  public void display() {
    System.out.println(quote);
    System.out.println(name);
  }
}