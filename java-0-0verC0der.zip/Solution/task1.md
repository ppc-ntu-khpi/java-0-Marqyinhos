# Завдання 1
## До зміни коду:
![alt-text](/Solution/task1.1.jpg)

## Після зміни коду:
![alt-text](/Solution/task1.2.jpg)

