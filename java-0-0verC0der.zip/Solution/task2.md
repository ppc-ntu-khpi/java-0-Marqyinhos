# Завдання 2
## До зміни коду:
![alt-text](/Solution/task2.1.jpg)

## Після зміни коду:
![alt-text](/Solution/task2.2.jpg)